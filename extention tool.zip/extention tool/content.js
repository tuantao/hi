// TaoF - Facebook Tool — content.js (Sửa lỗi selector quét bạn bè)

/******************** GLOBAL ********************/
let running = false, paused = false, ticking = false;
let clickedCount = 0;
let mode = "ADD";
let maxPerRun = 50, minDelayMs = 500, maxDelayMs = 1200;
let minMutual = 0, inc = "", exc = "";
let gender = "ANY", region = "", minFriends = 0, ageMin = 0, ageMax = 0;
let postText = "";
let queue = [];
let backoffLevel = 0;
let scanning = false;
let scanAbort = false;

// === BIẾN MỚI CHO TÍNH NĂNG QUÉT TƯƠNG TÁC ===
let isScanningInteractions = false;
let scanInteractionsAbort = false;

/******************** HELPERS (ĐÃ NÂNG CẤP) ********************/
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const rnd   = (min = minDelayMs, max = maxDelayMs) => Math.floor(min + Math.random()*(max-min));
const norm  = (t) => (t || "").replace(/\u00A0/g," ").replace(/\s+/g," ").trim();
function fold(s){ return (s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/đ/g,"d").replace(/\s+/g," ").trim(); }
function log(...a){ console.log("[TaoF]", ...a); }
function visible(el){ if(!el) return false; const cs=getComputedStyle(el); const r=el.getBoundingClientRect(); return cs.display!=="none"&&cs.visibility!=="hidden"&&+cs.opacity!==0&&r.width>10&&r.height>10; }
function forceClick(el){ try{ el.scrollIntoView({behavior:"smooth", block:"center"});}catch{} try{ el.focus({preventScroll:true}); }catch{} const ev={bubbles:true,cancelable:true,view:window}; try{el.dispatchEvent(new MouseEvent("mouseover",ev));}catch{} try{el.dispatchEvent(new MouseEvent("mousedown",ev));}catch{} try{el.dispatchEvent(new MouseEvent("mouseup",ev));}catch{} try{el.click();}catch{} }
function dlg(){ return document.querySelector('[role="dialog"]')||null; }

function pumpScroll(delta = 1000, specificElement = null) {
    let prog = false;
    const scrollers = new Set();
    if (specificElement) {
        scrollers.add(specificElement);
    } else {
        scrollers.add(window);
        document.querySelectorAll('*').forEach(el => {
            try { if (el.scrollHeight > el.clientHeight && el.clientHeight > 100) scrollers.add(el); } catch(e){}
        });
    }
    for (const el of scrollers) {
        const before = el.scrollTop ?? el.scrollY;
        if (typeof el.scrollBy === 'function') el.scrollBy({ top: delta, behavior: 'smooth' });
        else el.scrollTop = before + delta;
        if ((el.scrollTop ?? el.scrollY) > before) prog = true;
    }
    return prog;
}

async function ensureButtons(getter, lim=1, triesMax=40){ let tries=0; while(running&&tries<triesMax){ await waitIfPaused(); const btns=getter(); if(btns.length>=lim) return btns; pumpScroll(1200); await sleep(350); tries++; } return getter(); }
async function waitIfPaused(){ while(running && paused){ await sleep(250); } }
function now(){ return new Date().toISOString(); }
function sendLog(row){ try{ chrome.runtime.sendMessage({ cmd:"LOG", row }); }catch{} }
function highlight(el, color="#00ccff"){ try{ el.style.outline=`3px solid ${color}`; el.style.borderRadius="6px"; el.scrollIntoView({behavior:"smooth", block:"center"}); }catch{} }

/******************** Kill-switch: ESC×2 ********************/
let escTimes = [];
window.addEventListener("keydown", (e)=>{
  if (e.key === "Escape") {
    const t = Date.now(); escTimes = escTimes.filter(x=>t-x<1000); escTimes.push(t);
    if (escTimes.length >= 2) {
      log("Kill-switch STOP");
      running = false; paused=false;
      if (scanning) { scanAbort = true; }
      if (isScanningInteractions) { scanInteractionsAbort = true; }
    }
  }
});

/******************** Deep scrape (Friends filters) ********************/
// ... (Toàn bộ các hàm từ fetchHTML đến resolveGroupNames giữ nguyên như cũ)
async function fetchHTML(url){
  try{
    const u = new URL(url, location.origin);
    if (u.hostname === "www.facebook.com") u.hostname = "m.facebook.com";
    const res = await fetch(u.toString(), { credentials: "include" });
    if (!res.ok) return "";
    return await res.text();
  }catch{ return ""; }
}
function parseGender(html){
  if (/(giới tính|gender)[^<]{0,40}(nam|male)/i.test(html)) return "MALE";
  if (/(giới tính|gender)[^<]{0,40}(nữ|female)/i.test(html)) return "FEMALE";
  return "UNKNOWN";
}
function parseRegion(html){
  const m = html.match(/(Sống tại|Lives in|Đến từ|From)[^<]{0,80}/i);
  return m ? norm(m[0]) : "";
}
function parseFriendsCount(html){
  const m = html.match(/(Bạn bè|Friends)[^0-9]{0,10}([\d., ]{1,7})/i);
  if (!m) return 0;
  const n = parseInt(m[2].replace(/[^\d]/g,""),10);
  return Number.isFinite(n)?n:0;
}
function parseAge(html){
  const m = html.match(/(\d{4})/);
  if (!m) return 0;
  const y = parseInt(m[1],10); const nowY = new Date().getFullYear(); const age = nowY - y;
  return (age>0 && age<120) ? age : 0;
}
async function deepCheck(profileUrl){
  const html = await fetchHTML(profileUrl);
  const g  = parseGender(html);
  const r  = parseRegion(html);
  const fc = parseFriendsCount(html);
  const ag = parseAge(html);
  return { g, r, fc, ag };
}
function needDeepFilter(){ return (gender!=="ANY") || !!region || (minFriends>0) || (ageMin>0) || (ageMax>0); }
function passNameFilter(container){
  const name = norm(
    container.querySelector('strong, a[role="link"]')?.innerText ||
    container.querySelector('[dir="auto"]')?.innerText || ""
  ); if (!name) return true;
  const nameF = fold(name);
  const incs = inc.split(",").map(s=>fold(s)).filter(Boolean);
  const excs = exc.split(",").map(s=>fold(s)).filter(Boolean);
  if (incs.length && !incs.some(k => nameF.includes(k))) return false;
  if (excs.some(k => nameF.includes(k))) return false;
  return true;
}
function extractMutual(c){
  const t = norm(c.innerText || "");
  const m = t.match(/(\d+)\s+(mutual friend|mutual friends|bạn chung)/i);
  return m ? parseInt(m[1],10) : 0;
}
function profileUrlFromCard(c){
  const a = c.querySelector('a[href*="facebook.com/"], a[role="link"][href]');
  if (!a) return "";
  let href = a.getAttribute("href")||"";
  if (href.startsWith("/")) href = new URL(href, location.origin).toString();
  if (!/https?:/.test(href)) href = `https://www.facebook.com${href}`;
  return href;
}
function parsePageTitle(html){
  let m = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i);
  if (m) return m[1].trim();
  m = html.match(/<title>([^<]+)<\/title>/i);
  if (m) return m[1].replace(/\s*\|\s*Facebook.*$/i,'').trim();
  return "";
}
async function resolveGroupNames(items, maxFetch = 15){
  for (const it of items) {
    if (scanAbort) break;
    if (!it.name || it.name === it.url) {
      try {
        const html = await fetchHTML(it.url);
        const t = parsePageTitle(html);
        if (t) it.name = t;
      } catch {}
      if (--maxFetch <= 0) break;
    }
  }
}
/******************** Pages/Groups/Friends helpers ********************/
// ... (Tất cả các hàm tìm kiếm và hành động như findButtonsByTextsOrAria, doPageUnfollow, findAddButtons, v.v. giữ nguyên)
function findButtonsByTextsOrAria(texts, root=document){
  const set = new Set();
  const tokens = texts.map(fold);
  const add = (el) => {
    const c = el.closest('button, div[role="button"], a[role="button"], div[tabindex]') || el;
    if (visible(c)) set.add(c);
  };
  root.querySelectorAll('button, div[role="button"], a[role="button"], a, span, strong')
    .forEach(el => { const t = fold(el.innerText || el.textContent || ""); if (t && tokens.some(k => t.includes(k))) add(el); });
  root.querySelectorAll('[aria-label]').forEach(el => { const a = fold(el.getAttribute('aria-label') || ""); if (a && tokens.some(k => a.includes(k))) add(el); });
  return [...set].sort((a,b)=>a.getBoundingClientRect().top - b.getBoundingClientRect().top);
}
async function clickMenuChoice(texts){
  const scope = dlg() || document;
  const btn = findButtonsByTextsOrAria(texts, scope)[0];
  if (btn) { forceClick(btn); await sleep(160); return true; }
  return false;
}
function firstPageLinkFromList() {
  const cards = [...document.querySelectorAll('[role="article"], [data-visualcompletion], [class*="x"]')];
  for (const c of cards) {
    const t = (c.innerText || "").toLowerCase();
    if (/following|đang theo dõi|đã theo dõi/.test(t)) {
      const a = c.querySelector('a[role="link"][href]');
      if (a && visible(a)) return a;
    }
  }
  const links = [...document.querySelectorAll('a[role="link"][href]')];
  return links.find(a => {
    const href = a.getAttribute('href') || '';
    return visible(a) && (/\/pages\//.test(href) || /^\/[^/?#]+\/?$/.test(href));
  }) || null;
}
function findAddButtons(){
  const res = new Set();
  document.querySelectorAll('[aria-label*="Add friend" i], [aria-label*="Kết bạn" i]').forEach(el=>res.add(el));
  document.querySelectorAll('button, div[role="button"], a').forEach(el=>{
    const t = norm(el.innerText || el.textContent);
    if (/Add\s*friend|Kết bạn|Thêm bạn bè/i.test(t)) {
      const c = el.closest('button, div[role="button"], a[role="button"], div[tabindex]')||el;
      if (visible(c)) res.add(c);
    }
  });
  let arr = [...res].filter(btn=>{
    const card = btn.closest('[role="article"], [data-visualcompletion], [role="row"], [class*="x"]') || document;
    if (!passNameFilter(card)) return false;
    return extractMutual(card) >= minMutual;
  });
  if (needDeepFilter()) {
    arr = arr.filter(btn=>{
      const card = btn.closest('[role="article"], [data-visualcompletion], [role="row"], [class*="x"]') || document;
      const url = profileUrlFromCard(card); if (!url) return false; btn.__taof_profile = url; return true;
    });
  }
  arr.sort((a,b)=>a.getBoundingClientRect().top-b.getBoundingClientRect().top);
  return arr;
}
function findCancelButtons(){
  const root = dlg() || document;
  const res = new Set();
  const TXT = /(Cancel\s*request|Hủy\s*lời\s*mời|Huỷ\s*lời\s*mời|Hủy\s*yêu\s*cầu|Huỷ\s*yêu\s*cầu)/i;
  root.querySelectorAll('button, div[role="button"], a, span').forEach(el=>{
    const t = norm(el.innerText || el.textContent);
    if (TXT.test(t)) {
      const c = el.closest('button, div[role="button"], a[role="button"], div[tabindex]') || el;
      if (visible(c)) res.add(c);
    }
  });
  return [...res].sort((a,b)=>a.getBoundingClientRect().top-b.getBoundingClientRect().top);
}
async function tryConfirmCancel(){
  const root = dlg() || document;
  const ok = [...root.querySelectorAll('button, div[role="button"]')].find(el =>
    /(Cancel\s*request|OK|Confirm|Hủy|Huỷ)/i.test(norm(el.innerText || el.textContent)));
  if (ok) { forceClick(ok); await sleep(120); }
}
function findConfirmButtons(){
  const res = new Set();
  document.querySelectorAll('button, div[role="button"], a').forEach(el=>{
    const t = norm(el.innerText || el.textContent);
    if (/Confirm|Xác nhận/i.test(t)) {
      const card = el.closest('[role="article"], [data-visualcompletion], [role="row"], [class*="x"]') || document;
      if (!passNameFilter(card)) return;
      if (extractMutual(card) < minMutual) return;
      const c = el.closest('button, div[role="button"], a[role="button"], div[tabindex]') || el;
      if (visible(c)) res.add(c);
      if (needDeepFilter()) {
        const url = profileUrlFromCard(card);
        if (url) c.__taof_profile = url;
      }
    }
  });
  return [...res].sort((a,b)=>a.getBoundingClientRect().top-b.getBoundingClientRect().top);
}
function findUnfriendMenus(){
  const items = [];
  document.querySelectorAll('button, div[role="button"]').forEach(el=>{
    const t = norm(el.innerText || el.textContent);
    if (/Friends|Bạn bè/i.test(t) && visible(el)) {
      const card = el.closest('[role="article"], [data-visualcompletion], [role="row"], [class*="x"]') || document;
      if (!passNameFilter(card)) return;
      if (extractMutual(card) < minMutual) return;
      const url = needDeepFilter() ? profileUrlFromCard(card) : "";
      items.push({ menuBtn: el, card, url });
    }
  });
  return items.sort((a,b)=>a.menuBtn.getBoundingClientRect().top - b.menuBtn.getBoundingClientRect().top);
}
async function openMenuAndUnfriend(item){
  if (needDeepFilter() && item.url) {
    const meta = await deepCheck(item.url);
    if (gender!=="ANY" && meta.g!==gender) return false;
    if (region && !fold(meta.r).includes(fold(region))) return false;
    if (minFriends>0 && meta.fc < minFriends) return false;
    if (ageMin>0 && (meta.ag||0) < ageMin) return false;
    if (ageMax>0 && (meta.ag||999) > ageMax) return false;
  }
  forceClick(item.menuBtn); await sleep(120);
  const scope = dlg() || document;
  const target = [...scope.querySelectorAll('button, div[role="button"], a')].find(el =>
    /Unfriend|Huỷ kết bạn|Hủy kết bạn/i.test(norm(el.innerText || el.textContent)));
  if (target) { forceClick(target); await sleep(120); }
  const ok = [...(dlg()||document).querySelectorAll('button, div[role="button"]')].find(el =>
    /(Confirm|OK|Unfriend|Huỷ|Hủy)/i.test(norm(el.innerText || el.textContent)));
  if (ok) { forceClick(ok); await sleep(120); }
  return true;
}
async function doPageUnfollow(){
  let btn = findButtonsByTextsOrAria(["Following","Đang theo dõi","Da theo doi","Đã theo dõi"])[0]
         || findButtonsByTextsOrAria(["...","Khác"])[0];
  if (btn) {
    forceClick(btn); await sleep(160);
    await clickMenuChoice(["Unfollow","Bỏ theo dõi","Hủy theo dõi"]);
    await sleep(160);
    return true;
  }
  if (await clickMenuChoice(["Unfollow","Bỏ theo dõi","Hủy theo dõi"])) return true;
  return false;
}
async function doPageUnlike() {
  if (await clickMenuChoice(["Unlike", "Bỏ thích", "Hủy thích", "Bo thich"])) return true;
  let btn = findButtonsByTextsOrAria(["Liked", "Đã thích", "Thích"])[0]
         || findButtonsByTextsOrAria(["...","Khác"])[0]
         || findButtonsByTextsOrAria(["Following","Đang theo dõi","Đã theo dõi"])[0];
  if (btn) {
    forceClick(btn); await sleep(250);
    if (await clickMenuChoice(["Unlike", "Bỏ thích", "Hủy thích", "Bo thich"])) { await sleep(200); return true; }
  }
  const link = firstPageLinkFromList();
  if (link) {
    forceClick(link); await sleep(1200);
    let headerBtn = findButtonsByTextsOrAria(["Liked","Đã thích","Thích"])[0]
                 || findButtonsByTextsOrAria(["...","Khác"])[0]
                 || findButtonsByTextsOrAria(["Following","Đang theo dõi","Đã theo dõi"])[0];
    if (headerBtn) {
      forceClick(headerBtn); await sleep(250);
      if (await clickMenuChoice(["Unlike","Bỏ thích","Hủy thích","Bo thich"])) { await sleep(200); return true; }
    }
  }
  if (await clickMenuChoice(["Unlike", "Bỏ thích", "Hủy thích"])) return true;
  return false;
}
function findJoinGroupButtons() {
  const results = new Set();
  document.querySelectorAll(
    '[aria-label*="Join group" i], [aria-label*="Join Group" i], ' +
    '[aria-label*="Tham gia nhóm" i], [aria-label*="Tham gia" i]'
  ).forEach(el => {
    const c = el.closest('button, div[role="button"], a[role="button"], div[tabindex]') || el;
    if (visible(c)) results.add(c);
  });
  document.querySelectorAll('button, div[role="button"], a[role="button"], a, span, strong')
    .forEach(el => {
      const t = fold(el.innerText || el.textContent || "");
      if (/^(join group|join|tham gia nhóm|tham gia)$/.test(t)) {
        const c = el.closest('button, div[role="button"], a[role="button"], div[tabindex]') || el;
        if (visible(c)) results.add(c);
      }
    });
  document.querySelectorAll('[data-testid*="join"], [data-testid*="group_suggestion_join"]')
    .forEach(el => { const c = el.closest('button, div[role="button"], a[role="button"], div[tabindex]') || el; if (visible(c)) results.add(c);});
  return [...results].sort((a,b)=>a.getBoundingClientRect().top - b.getBoundingClientRect().top);
}
async function doGroupJoin(){
  const markers = findButtonsByTextsOrAria(["Requested","Request sent","Đã yêu cầu","Đang chờ duyệt","Joined","Thành viên","Đã tham gia"]);
  if (markers.length) return false;
  const btns = findJoinGroupButtons();
  if (!btns.length) return false;
  const btn = btns[0];
  highlight(btn, "#22c55e");
  forceClick(btn);
  await sleep(350);
  await clickMenuChoice(["Join group","Request to join","Gửi yêu cầu","Submit","Send"]);
  return true;
}
async function doGroupPostAssist() {
  let openBtn = findButtonsByTextsOrAria(["create post","tạo bài viết","viết gì đó","what's on your mind","write something","bắt đầu thảo luận"])[0];
  if (openBtn) { forceClick(openBtn); await sleep(500); }
  let scope = dlg() || document;
  let editor = scope.querySelector('[role="textbox"][contenteditable="true"]')
             || scope.querySelector('[contenteditable="true"]')
             || scope.querySelector('textarea');
  if (!editor) {
    const mini = findButtonsByTextsOrAria(["write something","viết gì đó","what's on your mind"], document)[0];
    if (mini) { forceClick(mini); await sleep(500); scope = dlg() || document;
      editor = scope.querySelector('[role="textbox"][contenteditable="true"]') || scope.querySelector('[contenteditable="true"]') || scope.querySelector('textarea');
    }
  }
  if (!editor) return false;
  try {
    editor.focus();
    if (editor.tagName === "TEXTAREA") { editor.value = postText; editor.dispatchEvent(new Event("input", {bubbles:true})); }
    else { document.execCommand("selectAll", false, null); document.execCommand("insertText", false, postText); editor.dispatchEvent(new InputEvent("input", {bubbles:true})); }
  } catch {}
  const postBtn = findButtonsByTextsOrAria(["post","đăng","share","chia sẻ"], scope)[0];
  if (postBtn) highlight(postBtn, "#22c55e");
  return true;
}
/******************** Adaptive Backoff ********************/
function blockedSignalsPresent(){
  const txt = norm(document.body.innerText || "");
  return /try again later|action blocked|tạm thời bị chặn|thử lại sau/i.test(txt);
}
function increaseBackoff(){
  backoffLevel = Math.min(backoffLevel+1, 4);
  const factor = 1 + backoffLevel*0.5;
  minDelayMs = Math.floor(minDelayMs*factor);
  maxDelayMs = Math.floor(maxDelayMs*factor);
  console.warn("[TaoF] Backoff level", backoffLevel, "→ delay", minDelayMs, maxDelayMs);
}

/******************** IMPROVED SCAN GROUPS ********************/
function canonicalGroupURL(href) {
  try {
    const u = new URL(href, location.origin);
    if (u.hostname === "m.facebook.com" || u.hostname === "mobile.facebook.com") { u.hostname = "www.facebook.com"; }
    const m = u.pathname.match(/\/groups\/([a-zA-Z0-9._-]+)/i);
    if (!m) return "";
    return `${u.origin}/groups/${m[1]}/`;
  } catch { return ""; }
}

async function scanAllGroups() {
    if (scanning) { scanAbort = true; await sleep(150); }
    scanning = true; scanAbort = false; log("Starting group scan...");

    const seenUrls = new Set();
    const groups = [];
    const BAD_PATHS = /\/groups\/(feed|discover|create|events|photos|files|sale_posts|saved|notifications|membership_questions|rules)/i;
    const timeStampRegex = /^\d+ (year|month|week|day|hour|minute|second)s? ago/i;

    function collectGroupsFromPage() {
        document.querySelectorAll('a[href*="/groups/"]').forEach(a => {
            if (!visible(a)) return;
            const href = a.getAttribute('href') || "";
            const canonUrl = canonicalGroupURL(href);
            if (canonUrl && !seenUrls.has(canonUrl) && !BAD_PATHS.test(canonUrl)) {
                let name = "";
                const card = a.closest('[role="article"], [role="listitem"], div[data-visualcompletion="ignore"]');
                if (card) {
                    const heading = card.querySelector('[role="heading"] span[dir="auto"], [role="heading"] span > span');
                    if(heading) name = norm(heading.innerText);
                }
                if (!name) name = norm(a.innerText || a.getAttribute('aria-label'));
                if (name && !timeStampRegex.test(name.trim())) {
                    seenUrls.add(canonUrl);
                    groups.push({ url: canonUrl, name: name });
                }
            }
        });
    }

    let scrollAttempts = 0, MAX_SCROLLS = 60, DEADLINE = Date.now() + 25000;
    while (!scanAbort && scrollAttempts < MAX_SCROLLS && Date.now() < DEADLINE) {
        collectGroupsFromPage();
        pumpScroll(window.innerHeight * 0.8);
        await sleep(350);
        scrollAttempts++;
    }
    collectGroupsFromPage();
    await resolveGroupNames(groups, 20);
    
    log(`Scan finished. Found ${groups.length} groups.`);
    scanning = false;
    if (scanAbort) return [];
    groups.sort((a,b)=>a.name.localeCompare(b.name, undefined, {sensitivity:"base"}));
    return groups;
}

/******************** RUNTIME ********************/
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // Sửa case "SCAN_GROUPS" thành "SCAN_GROUPS_AND_RETURN"
    if (msg?.cmd === "SCAN_GROUPS_AND_RETURN") {
        scanAllGroups()
          .then(groups => {
              // Gửi kết quả về cho background script
              sendResponse({ status: "success", groups: groups });
          })
          .catch(e => {
              console.error("[TaoF] Scan failed:", e);
              sendResponse({ status: "error", message: e.message });
          });
        return true; // Giữ kết nối mở để chờ promise hoàn thành
    }
  
  // Listeners for popup commands
  if (msg?.cmd === "CONFIG") {
    mode = msg.mode || mode; maxPerRun = msg.maxPerRun ?? maxPerRun; minDelayMs = msg.minDelayMs ?? minDelayMs;
    maxDelayMs = msg.maxDelayMs ?? maxDelayMs; minMutual = msg.minMutual ?? minMutual; inc = msg.inc ?? inc;
    exc = msg.exc ?? exc; gender = msg.gender ?? gender; region = msg.region ?? region;
    minFriends = msg.minFriends ?? minFriends; ageMin = msg.ageMin ?? ageMin; ageMax = msg.ageMax ?? ageMax;
    postText = msg.postText ?? postText;
  }
  if (msg?.cmd === "SET_QUEUE") { queue = msg.queue || []; }
  if (msg?.cmd === "START") {
    if (!running) {
        running = true; paused = false; clickedCount = 0; backoffLevel = 0; loop();
    }
  }
  if (msg?.cmd === "STOP") { running = false; paused = false; if(scanning) scanAbort = true; }
  if (msg?.cmd === "PAUSE") { paused = true; }
  if (msg?.cmd === "RESUME") { paused = false; }

  // Listener cho tính năng quét tương tác
  if (msg?.cmd === "SCAN_NON_INTERACTIVE_FRIENDS") {
    if (isScanningInteractions) {
      log("Một quá trình quét khác đang chạy. Vui lòng chờ.");
      sendResponse({ status: "already_running" });
      return true;
    }
    runFullScan(msg.limit);
    sendResponse({ status: "started" });
    return true;
  }

  return true;
});


/******************** MAIN LOOP ********************/
async function nextInQueue(){ try{ return await new Promise(res=>chrome.runtime.sendMessage({cmd:"NEXT_IN_QUEUE"}, r=>res(r))); }catch{} }
async function loop(){
  if (ticking) return; 
  ticking = true;
  log("loop start", { mode, maxPerRun });

  while (running) {
    await waitIfPaused();
    if (clickedCount >= maxPerRun) { log("Reached maxPerRun -> stop"); running=false; break; }
    // ... (Toàn bộ logic của hàm loop giữ nguyên như cũ)
    if (["ADD_FROM_LIST","PAGES_UNFOLLOW","PAGES_UNLIKE","GROUPS_JOIN","GROUPS_POST_ASSIST"].includes(mode) && queue && queue.length) {
      const cur = queue[0];

      if (mode === "ADD_FROM_LIST" && /^\d+$/.test(cur)) {
        const url = `https://www.facebook.com/profile.php?id=${cur}`;
        if (!location.href.startsWith(url)) { location.href = url; await sleep(1000); }
      } else if (mode === "ADD_FROM_LIST" && /[^0-9/.:]/.test(cur) && !/facebook\.com/i.test(cur)) {
        const url = `https://www.facebook.com/search/people/?q=${encodeURIComponent(cur)}`;
        if (!location.href.startsWith(url)) { location.href = url; await sleep(1000); }
      } else { if (!location.href.startsWith(cur)) { location.href = cur; await sleep(1000); } }

      await sleep(400);
      let ok = false;

      if (mode==="PAGES_UNFOLLOW") ok = await doPageUnfollow();
      else if (mode==="PAGES_UNLIKE") ok = await doPageUnlike();
      else if (mode==="GROUPS_JOIN")  ok = await doGroupJoin();
      else if (mode==="GROUPS_POST_ASSIST") ok = await doGroupPostAssist();
      else if (mode==="ADD_FROM_LIST") {
        const b = (await ensureButtons(findAddButtons, 1, 40))[0];
        if (b) { forceClick(b); ok = true; }
      }

      if (ok) { clickedCount++; sendLog({ ts: now(), mode, action: "LIST_ACT", url: cur }); }
      await nextInQueue();
      await sleep(rnd());
      continue;
    }
    let btns = [];
    if (mode==="ADD")                btns = await ensureButtons(findAddButtons, 1, 50);
    else if (mode==="CANCEL_SENT")   btns = await ensureButtons(findCancelButtons, 1, 50);
    else if (mode==="ACCEPT_INCOMING") btns = await ensureButtons(findConfirmButtons, 1, 50);
    else if (mode==="UNFRIEND") {
      const items = findUnfriendMenus();
      if (!items.length) { pumpScroll(1000); await sleep(300); continue; }
      const it = items[0];
      const ok = await openMenuAndUnfriend(it);
      if (ok) { clickedCount++; sendLog({ ts: now(), mode, action:"UNFRIEND", url: it.url||"" }); }
      await sleep(rnd()); continue;
    }
    else if (mode==="PAGES_UNFOLLOW") { if (await doPageUnfollow()) { clickedCount++; await sleep(rnd()); continue; } pumpScroll(800); await sleep(300); continue; }
    else if (mode==="PAGES_UNLIKE")   { if (await doPageUnlike())   { clickedCount++; await sleep(rnd()); continue; } pumpScroll(800); await sleep(300); continue; }
    else if (mode==="GROUPS_JOIN")    {
      const joins = await ensureButtons(findJoinGroupButtons, 1, 40);
      if (joins.length) { highlight(joins[0], "#22c55e"); forceClick(joins[0]); await sleep(350); await clickMenuChoice(["Join group","Request to join","Gửi yêu cầu","Submit","Send"]); clickedCount++; await sleep(rnd()); continue; }
      pumpScroll(1000); await sleep(400); continue;
    }
    if (!btns.length && running) { log("No button -> scroll & wait"); pumpScroll(1200); await sleep(400); continue; }
    if(btns.length > 0) {
        const btn = btns[0];
        const card = btn.closest('[role="article"], [data-visualcompletion], [role="row"], [class*="x"]') || document;
        const url  = profileUrlFromCard(card);
        if (url) {
          const seen = await new Promise(r=>chrome.runtime.sendMessage({cmd:"IS_SEEN", url}, a=>r(a?.seen)));
          if (seen) { pumpScroll(420); continue; }
        }
        if ((mode==="ADD" || mode==="ACCEPT_INCOMING") && needDeepFilter()) {
          if (url) {
            const meta = await deepCheck(url);
            if (gender!=="ANY" && meta.g!==gender) { pumpScroll(420); continue; }
            if (region && !fold(meta.r).includes(fold(region))) { pumpScroll(420); continue; }
            if (minFriends>0 && meta.fc < minFriends) { pumpScroll(420); continue; }
            if (ageMin>0 && (meta.ag||0) < ageMin) { pumpScroll(420); continue; }
            if (ageMax>0 && (meta.ag||999) > ageMax) { pumpScroll(420); continue; }
          }
        }
        forceClick(btn);
        clickedCount++;
        sendLog({ ts: now(), mode, action: (mode==="ADD" ? "ADD" : "ACCEPT"), url });
        if (url) chrome.runtime.sendMessage({ cmd:"MARK_SEEN", url });
        if (mode==="CANCEL_SENT") {
          await sleep(120); await tryConfirmCancel(); pumpScroll(420);
        }
    }
    if (blockedSignalsPresent()) {
      increaseBackoff();
      if (backoffLevel >= 3) { log("Blocked hard → STOP"); running=false; break; }
    }
    await sleep(rnd());
  }
  ticking=false; 
  log("loop end");
}

/******************************************************************/
/********** QUÉT BẠN BÈ KHÔNG TƯƠNG TÁC (LOGIC MỚI) ***************/
/******************************************************************/

async function runFullScan(postLimit) {
  isScanningInteractions = true;
  scanInteractionsAbort = false;
  log(`BẮT ĐẦU QUÉT BẠN BÈ KHÔNG TƯƠNG TÁC (giới hạn ${postLimit} bài viết).`);
  alert(`Quá trình quét sẽ bắt đầu. Vui lòng không đóng tab này.\nĐể dừng khẩn cấp, nhấn phím ESC 2 lần.\nQuá trình có thể mất rất nhiều thời gian.`);

  try {
    const friends = await navigateToAndGetAllFriends();
    if (scanInteractionsAbort || friends.size === 0) {
      throw new Error("Không thể lấy danh sách bạn bè hoặc đã bị hủy.");
    }
    log(`Đã lấy được ${friends.size} bạn bè.`);
    const interactors = await navigateToAndScanPosts(postLimit);
    if (scanInteractionsAbort) {
      throw new Error("Quá trình quét bài viết đã bị hủy.");
    }
    log(`Đã tìm thấy ${interactors.size} người tương tác.`);
    displayScanResults(friends, interactors);
  } catch (error) {
    log("LỖI:", error.message);
    alert(`Quá trình quét đã dừng với lỗi: ${error.message}`);
  } finally {
    isScanningInteractions = false;
    scanInteractionsAbort = false;
    log("QUÁ TRÌNH QUÉT ĐÃ KẾT THÚC.");
  }
}



async function navigateToAndScanPosts(postLimit) {
    const profileUrl = "https://www.facebook.com/me";
    if (!window.location.href.includes("facebook.com/me") && !window.location.href.includes("profile.php")) {
        log("Đang điều hướng tới trang cá nhân...");
        window.location.href = profileUrl;
        await sleep(5000);
    }

    const interactors = new Set();
    const scannedPosts = new Set();
    let collectedPosts = [];
    
    while (collectedPosts.length < postLimit && !scanInteractionsAbort) {
        pumpScroll(window.innerHeight);
        await sleep(rnd(2000, 3000));
        
        const postsOnScreen = document.querySelectorAll('div[data-pagelet*="FeedUnit"]');
        postsOnScreen.forEach(post => {
            const postIdentifier = post.innerText.slice(0, 100);
            if (!scannedPosts.has(postIdentifier)) {
                collectedPosts.push(post);
                scannedPosts.add(postIdentifier);
            }
        });

        log(`Đã thu thập được ${collectedPosts.length} / ${postLimit} bài viết.`);
        if (collectedPosts.length >= postLimit) break;
    }

    for (let i = 0; i < Math.min(collectedPosts.length, postLimit); i++) {
        if (scanInteractionsAbort) break;
        const post = collectedPosts[i];
        highlight(post, "#facc15");
        log(`Đang xử lý bài viết ${i + 1} / ${postLimit}...`);

        const reactionButton = post.querySelector('span[aria-label*="See who reacted to this"]');
        if (reactionButton) {
            forceClick(reactionButton);
            await sleep(rnd(2500, 4000));
            const modal = dlg();
            if (modal) {
                let modalNoProgress = 0;
                while (modalNoProgress < 3 && !scanInteractionsAbort) {
                    const initialInteractorSize = interactors.size;
                    modal.querySelectorAll('a[role="link"] > span, strong').forEach(el => {
                        if(el.innerText) interactors.add(norm(el.innerText));
                    });
                    const scrollableArea = modal.querySelector('[role="dialog"] > div > div');
                    pumpScroll(500, scrollableArea || modal);
                    await sleep(rnd(1000, 1500));
                    if (interactors.size === initialInteractorSize) {
                        modalNoProgress++;
                    } else {
                        modalNoProgress = 0;
                    }
                }
                log(`Đã thu thập ${interactors.size} người tương tác.`);
                const closeButton = modal.querySelector('[aria-label="Close"], [aria-label="Đóng"]');
                if (closeButton) forceClick(closeButton);
                await sleep(rnd(1500, 2500));
            }
        }
    }
    return interactors;
}

function displayScanResults(friends, interactors) {
    const nonInteractiveFriends = [];
    for (const friend of friends) {
        if (!interactors.has(friend)) {
            nonInteractiveFriends.push(friend);
        }
    }

    log("===== KẾT QUẢ QUÉT BẠN BÈ KHÔNG TƯƠNG TÁC =====");
    log(`Tổng số bạn bè: ${friends.size}`);
    log(`Tổng số người tương tác: ${interactors.size}`);
    log(`Số bạn bè không tương tác: ${nonInteractiveFriends.length}`);
    log("Danh sách chi tiết:", nonInteractiveFriends);
    console.log("Danh sách chi tiết (để copy):", JSON.stringify(nonInteractiveFriends, null, 2));

    alert(`Quét hoàn tất!\n\n- Tổng bạn bè: ${friends.size}\n- Người đã tương tác: ${interactors.size}\n- KHÔNG TƯƠNG TÁC: ${nonInteractiveFriends.length}\n\nXem danh sách chi tiết trong Console (nhấn F12).`);
    
    chrome.storage.local.set({
        'taoF_nonInteractiveFriends': nonInteractiveFriends,
        'taoF_scanTimestamp': new Date().toISOString()
    });
}
/******************************************************************/
/********** NÂNG CẤP: CÀO DỮ LIỆU BẠN BÈ (DATA-CENTRIC) ************/
/******************************************************************/

/**
 * Trích xuất UID hoặc username từ một URL profile Facebook.
 * @param {string} url 
 * @returns {string|null} UID hoặc username.
 */
function extractUidFromUrl(url) {
    try {
        const urlObj = new URL(url);
        const profileId = urlObj.searchParams.get('id');
        if (profileId) return profileId;

        // Dành cho các URL có dạng facebook.com/username
        const match = urlObj.pathname.match(/^\/([^/]+)/);
        if (match && match[1] && match[1] !== 'profile.php') {
            return match[1];
        }
        return null;
    } catch (e) {
        return null;
    }
}


/**
 * Vào trang friends/list, cuộn đến cuối và cào toàn bộ danh sách bạn bè.
 * @returns {Promise<Array<object>>} Mảng chứa các object bạn bè.
 */



// BÊN TRONG LISTENER onMessage của content.js
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    
    // ... (các case cũ của bạn)

    // === CASE MỚI: Lắng nghe lệnh cào dữ liệu ===
    if (msg.cmd === "FETCH_ALL_FRIENDS") {
        scrapeAllFriends()
            .then(friendsList => {
                sendResponse({ status: "success", friends: friendsList });
            })
            .catch(error => {
                console.error("Lỗi khi cào danh sách bạn bè:", error);
                sendResponse({ status: "error", message: error.message });
            });
        return true; // Giữ kết nối mở để chờ promise hoàn thành
    }

    // ... (các case cũ khác)
});


// ==== TaoF Clean Merge (2025-09-01): Robust friend fetching ====

function _taof_normText(s) {
  return (s || "").replace(/\u00A0/g, " ").replace(/\s+/g, " ").trim();
}
function _taof_extractUidFromUrl(url) {
  try {
    const u = new URL(url, location.origin);
    const id = u.searchParams.get("id");
    if (id) return id;
    const m = u.pathname.match(/^\/([^/?#]+)(?:\/)?/);
    if (m && m[1] && m[1] !== "profile.php") return m[1];
  } catch {}
  return "";
}
function _taof_collectFriendAnchors(root = document) {
  const set = new Set();
  root.querySelectorAll('div[role="listitem"] a[role="link"][href*="facebook.com/"]').forEach(a => { if (a && a.href) set.add(a); });
  root.querySelectorAll('a[href*="facebook.com"][role="link"]').forEach(a => { if (a && a.href) set.add(a); });
  const anchors = [...set].filter(a => {
    const href = a.getAttribute("href") || "";
    if (/\/friends\/|\/pages\/|\/groups\/|\/events\//i.test(href)) return false;
    return /profile\.php\?id=\d+/.test(href) || /^https?:\/\/(www\.)?facebook\.com\/[^/?#]+/i.test(href);
  });
  return anchors;
}
function _taof_extractFriendNameFromAnchor(a) {
  let name = "";
  const span = a.querySelector('span[dir="auto"], span');
  if (span && span.innerText) name = span.innerText;
  if (!name && a.innerText) name = a.innerText;
  return _taof_normText(name);
}

/**
 * Lấy TẬP tên bạn bè (Set<string>) — dùng cho tính năng "quét không tương tác".
 */
async function navigateToAndGetAllFriends() {
  const FRIENDS_URL = "https://www.facebook.com/friends/list";
  if (!location.href.startsWith(FRIENDS_URL)) {
    try { location.href = FRIENDS_URL; } catch {}
    await new Promise(r => setTimeout(r, 5000));
  }
  const names = new Set();
  const MORE_TEXTS = ["Xem thêm","Xem thêm bạn bè","Xem thêm kết quả","See more","See more friends","Load more","Show more"];
  const SLEEP = (ms)=>new Promise(r=>setTimeout(r,ms));
  function _text(n){ return (n?.innerText||n?.textContent||"").replace(/\s+/g," ").trim(); }
  function clickLoadMoreIfAny(){
    let clicked=false;
    const cands=[...document.querySelectorAll('div[role="button"],a[role="button"],a[role="link"],span')]
      .filter(n=>{const t=_text(n).toLowerCase(); return t && MORE_TEXTS.some(m=>t.includes(m.toLowerCase()));});
    for(const n of cands){ try{ if(getComputedStyle(n).display!=="none" && n.offsetParent!==null){ n.click(); clicked=true; } }catch{} }
    return clicked;
  }
  function getScrollers(){
    const set=new Set([document.scrollingElement||document.documentElement, window]);
    document.querySelectorAll('[role="main"], [data-pagelet], div, section').forEach(el=>{try{ if(el.scrollHeight>el.clientHeight && el.clientHeight>300) set.add(el);}catch{}});
    return [...set];
  }
  let noProgress=0, last=0, MAX_NO_PROGRESS=12;
  while(noProgress<MAX_NO_PROGRESS){
    _taof_collectFriendAnchors(document).forEach(a=>{ const n=_taof_extractFriendNameFromAnchor(a); if(n) names.add(n); });
    if(names.size===last) noProgress++; else noProgress=0;
    last=names.size;
    if(clickLoadMoreIfAny()){ await SLEEP(1500); continue; }
    for(const el of getScrollers()){ try{ if(el===window) window.scrollBy({top: innerHeight*0.9, behavior:"auto"}); else el.scrollTop = el.scrollTop + Math.min(1200, el.clientHeight*0.9);}catch{} }
    await SLEEP(1200+Math.floor(Math.random()*600));
  }
  return names;
}

/**
 * Lấy MẢNG đối tượng bạn bè {name, href, uid} — dùng cho "Tải/Làm Mới Danh Sách Bạn Bè".
 */
async function scrapeAllFriends() {
  const FRIENDS_URL = "https://www.facebook.com/friends/list";
  if (!location.href.startsWith(FRIENDS_URL)) {
    try { location.href = FRIENDS_URL; } catch {}
    await new Promise(r => setTimeout(r, 5000));
  }
  const map=new Map();
  const MORE_TEXTS=["Xem thêm","Xem thêm bạn bè","Xem thêm kết quả","See more","See more friends","Load more","Show more"];
  const SLEEP = (ms)=>new Promise(r=>setTimeout(r,ms));
  function _text(n){ return (n?.innerText||n?.textContent||"").replace(/\s+/g," ").trim(); }
  function clickLoadMoreIfAny(){
    let clicked=false;
    const cands=[...document.querySelectorAll('div[role="button"],a[role="button"],a[role="link"],span')]
      .filter(n=>{const t=_text(n).toLowerCase(); return t && MORE_TEXTS.some(m=>t.includes(m.toLowerCase()));});
    for(const n of cands){ try{ if(getComputedStyle(n).display!=="none" && n.offsetParent!==null){ n.click(); clicked=true; } }catch{} }
    return clicked;
  }
  function getScrollers(){
    const set=new Set([document.scrollingElement||document.documentElement, window]);
    document.querySelectorAll('[role="main"], [data-pagelet], div, section').forEach(el=>{try{ if(el.scrollHeight>el.clientHeight && el.clientHeight>300) set.add(el);}catch{}});
    return [...set];
  }
  let noProgress=0, last=0, MAX_NO_PROGRESS=12;
  while(noProgress<MAX_NO_PROGRESS){
    _taof_collectFriendAnchors(document).forEach(a=>{
      const href=a.href; const name=_taof_extractFriendNameFromAnchor(a);
      if(!href || !name) return;
      if(!map.has(href)) map.set(href, { name, href, uid: _taof_extractUidFromUrl(href) });
    });
    if(map.size===last) noProgress++; else noProgress=0;
    last=map.size;
    if(clickLoadMoreIfAny()){ await SLEEP(1500); continue; }
    for(const el of getScrollers()){ try{ if(el===window) window.scrollBy({top: innerHeight*0.9, behavior:"auto"}); else el.scrollTop = el.scrollTop + Math.min(1200, el.clientHeight*0.9);}catch{} }
    await SLEEP(1200+Math.floor(Math.random()*600));
  }
  return Array.from(map.values());
}
// ==== End Clean Merge ====
/* TaoF - Facebook Tool — background.js (Đã nâng cấp để tải dữ liệu + retry) */

let STATE = {
  mode: "ADD",
  maxPerRun: 50,
  minDelayMs: 500,
  maxDelayMs: 1200,
  minMutual: 0,
  inc: "",
  exc: "",
  gender: "ANY",
  region: "",
  minFriends: 0,
  ageMin: 0,
  ageMax: 0,
  postText: "",
  paused: false,
};

let QUEUE = [];
const SEEN = new Set();
let LOGS = [];

// =======================================================
// SECTION: CÁC HÀM HELPER
// =======================================================

/**
 * Tìm một tab Facebook có sẵn hoặc tạo một tab mới trong nền.
 * @returns {Promise<number|null>} ID của tab Facebook mục tiêu.
 */
async function findOrCreateFacebookTab() {
  // 1. Tìm kiếm tất cả các tab Facebook đang mở
  const tabs = await chrome.tabs.query({ url: "https://*.facebook.com/*" });

  if (tabs.length > 0) {
    // 2. Nếu có, trả về ID của tab đầu tiên tìm thấy
    console.log(`Đã tìm thấy tab Facebook có sẵn: ${tabs[0].id}`);
    return tabs[0].id;
  } else {
    // 3. Nếu không, tạo một tab mới trong nền (không active)
    console.log("Không tìm thấy tab Facebook. Đang tạo tab mới trong nền...");
    const newTab = await chrome.tabs.create({
      url: "https://www.facebook.com",
      active: false // Đây là chìa khóa để tab không nhảy lên màn hình
    });
    return newTab.id;
  }
}

/**
 * Gửi một tin nhắn đến một tab cụ thể bằng ID (fire-and-forget).
 * @param {number} tabId ID của tab cần gửi tin nhắn đến.
 * @param {object} msg Nội dung tin nhắn.
 */
async function sendMessageToTab(tabId, msg) {
  if (!tabId) return;
  try {
    await chrome.tabs.sendMessage(tabId, msg);
  } catch (e) {
    console.error(`Không thể gửi tin nhắn đến tab ${tabId}:`, e);
    if (e.message && e.message.includes("Receiving end does not exist")) {
      console.log(`Đang thử tải lại tab ${tabId}...`);
      await chrome.tabs.reload(tabId);
      await new Promise(resolve => setTimeout(resolve, 2000)); // Chờ 2s cho tab tải lại
      await chrome.tabs.sendMessage(tabId, msg); // Thử gửi lại
    }
  }
}

/**
 * Gửi message và CHỜ phản hồi, có retry + reload tab nếu content chưa sẵn sàng.
 */
async function sendMessageToTabWithResponse(tabId, msg, retries = 3, waitMs = 2000) {
  for (let i = 0; i <= retries; i++) {
    try {
      const resp = await chrome.tabs.sendMessage(tabId, msg);
      return resp;
    } catch (e) {
      console.error("sendMessageToTabWithResponse error:", e);
      if (e.message && e.message.includes("Receiving end does not exist") && i < retries) {
        await chrome.tabs.reload(tabId);
        await new Promise(r => setTimeout(r, waitMs));
        continue;
      }
      throw e;
    }
  }
}

// --- Helper: tabs.sendMessage as Promise with timeout ---
function sendMessageWithCallback(tabId, message, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const timer = setTimeout(() => {
      if (done) return;
      done = true;
      reject(new Error("sendMessage timeout"));
    }, timeoutMs);

    try {
      chrome.tabs.sendMessage(tabId, message, (response) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        const err = chrome.runtime.lastError;
        if (err) reject(new Error(err.message || "runtime.lastError"));
        else resolve(response);
      });
    } catch (e) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      reject(e);
    }
  });
}

// --- Wrapper with retries + optional reload ---
async function sendMessageToTabWithResponse(tabId, msg, retries = 2, waitMs = 1500) {
  for (let i = 0; i <= retries; i++) {
    try {
      const resp = await sendMessageWithCallback(tabId, msg, 25000);
      return resp;
    } catch (e) {
      console.warn("sendMessageToTabWithResponse error:", e?.message || e);
      if (i < retries) {
        try { await chrome.tabs.reload(tabId); } catch {}
        await new Promise(r => setTimeout(r, waitMs));
        continue;
      }
      throw e;
    }
  }
}
async function ensureTargetTab(tabId, mode) {
  const targets = {
    "ADD": ["https://www.facebook.com/friends/suggestions"],
    "ACCEPT_INCOMING": ["https://www.facebook.com/friends/requests/"],
    "CANCEL_SENT": ["https://www.facebook.com/friends/requests/?outgoing=1"],
    "UNFRIEND": ["https://www.facebook.com/friends/list"],
    "ADD_FROM_LIST": ["https://www.facebook.com/"],
    "PAGES_UNLIKE": ["https://www.facebook.com/pages/?category=liked"],
    "PAGES_UNFOLLOW": ["https://www.facebook.com/pages/?category=liked"],
    "GROUPS_JOIN": ["https://www.facebook.com/groups/discover/"],
    "GROUPS_POST_ASSIST": ["https://www.facebook.com/groups/you/"],
  };

  const want = targets[mode];
  if (!want || !want.length || !tabId) return;

  const tab = await chrome.tabs.get(tabId);
  if (!tab.url || !want.some(u => tab.url.startsWith(u))) {
    try { await chrome.tabs.update(tabId, { url: want[0] }); } catch {}
  }
}

// --- Các hàm xử lý CSV ---
function toCsvRow(values) {
  return values.map(v => {
    const s = (v ?? "").toString();
    if (/[\",\n]/.test(s)) return `\"${s.replace(/\"/g, '\"\"')}\"`;
    return s;
  }).join(",");
}

function logsToCsv(logs) {
  const header = ["time", "mode", "action", "url", "extra"];
  const lines = [toCsvRow(header)];
  for (const row of logs) {
    lines.push(
      toCsvRow([
        row.ts || "", row.mode || "", row.action || "", row.url || "",
        row.extra ? JSON.stringify(row.extra) : ""
      ])
    );
  }
  return lines.join("\n");
}

function arrayToCsv(headerRow, dataArray) {
  let csvContent = headerRow + "\n";
  csvContent += dataArray.join("\n");
  return "data:text/csv;charset=utf-8," + encodeURI(csvContent);
}

async function downloadCsv(filename, csvDataUri) {
  try {
    await chrome.downloads.download({
      url: csvDataUri,
      filename,
      conflictAction: "uniquify",
      saveAs: true
    });
  } catch (e) {
    console.error("Lỗi khi tải file CSV:", e);
  }
}

// =======================================================
// SECTION: LISTENER NỘI BỘ (TỪ POPUP/CONTENT SCRIPT)
// =======================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.cmd) {
    case "CONFIG":
      STATE = { ...STATE, ...msg };
      delete STATE.queue;
      break;
    case "SET_QUEUE":
      QUEUE = Array.isArray(msg.queue) ? msg.queue.slice(0, 1000) : [];
      break;
    case "NEXT_IN_QUEUE":
      if (QUEUE.length) QUEUE.shift();
      break;
    case "LOG":
      if (msg.row) LOGS.push(msg.row);
      break;
  }
  sendResponse?.({ ok: true });
  return true;
});


// =======================================================
// SECTION: LISTENER BÊN NGOÀI (TỪ WEBSITE ĐIỀU KHIỂN)
// =======================================================
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  console.log("Nhận được lệnh từ website:", msg);

  if (!sender.url.startsWith("https://tuantao.github.io")) { // <-- SỬA LẠI URL CỦA BẠN NẾU CẦN
    console.error("Lệnh từ một nguồn không xác định:", sender.url);
    return sendResponse({ status: "error", message: "Invalid sender" });
  }

  (async () => {
    let targetTabId;

    // Các lệnh không cần tab Facebook
    switch (msg.cmd) {
      case "PROXY_EXPORT_CSV":
        const generalLogsCsv = "data:text/csv;charset=utf-8," + encodeURI(logsToCsv(LOGS));
        downloadCsv(`TaoF_general_logs_${Date.now()}.csv`, generalLogsCsv);
        return sendResponse({ status: "export_started" });
      case "PROXY_CLEAR_LOG":
        LOGS = [];
        chrome.storage.local.remove(['taoF_nonInteractiveFriends', 'taoF_scanTimestamp']);
        return sendResponse({ status: "log_and_scan_results_cleared" });
      case "PROXY_GET_SCAN_RESULTS":
        const result = await chrome.storage.local.get(['taoF_nonInteractiveFriends', 'taoF_scanTimestamp']);
        return sendResponse({
          status: 'success',
          data: {
            friends: result.taoF_nonInteractiveFriends || [],
            timestamp: result.taoF_scanTimestamp || null
          }
        });
      case "PROXY_EXPORT_SCAN_RESULTS":
        const exportResult = await chrome.storage.local.get(['taoF_nonInteractiveFriends']);
        if (exportResult.taoF_nonInteractiveFriends && exportResult.taoF_nonInteractiveFriends.length > 0) {
          // Xuất theo định dạng 1 cột Name. Hỗ trợ nếu dữ liệu là string hoặc object.
          const lines = exportResult.taoF_nonInteractiveFriends.map(f => {
            if (typeof f === 'string') return f;
            return f?.name ?? '';
          });
          const friendsCsv = arrayToCsv("Name", lines);
          downloadCsv(`TaoF_non_interactive_friends_${Date.now()}.csv`, friendsCsv);
          return sendResponse({ status: 'success' });
        } else {
          return sendResponse({ status: 'error', message: 'No data to export' });
        }
    }

    // Các lệnh cần tab Facebook sẽ lấy tab ID trước
    try {
      targetTabId = await findOrCreateFacebookTab();
    } catch (e) {
      console.error("Không thể lấy tab Facebook:", e);
      return sendResponse({ status: "error", message: "Could not find or create a Facebook tab." });
    }

    // Gửi lệnh đến tab Facebook đã xác định
    switch (msg.cmd) {
      case "PROXY_START":
        await ensureTargetTab(targetTabId, msg.config.mode);
        await sendMessageToTab(targetTabId, { cmd: "CONFIG", ...msg.config });
        if (msg.queue && msg.queue.length > 0) {
          await sendMessageToTab(targetTabId, { cmd: "SET_QUEUE", queue: msg.queue });
        }
        if (msg.config.mode === 'SCAN_NON_INTERACTIVE') {
          await sendMessageToTab(targetTabId, { cmd: "SCAN_NON_INTERACTIVE_FRIENDS", limit: msg.config.scanPostLimit });
        } else {
          await sendMessageToTab(targetTabId, { cmd: "START" });
        }
        sendResponse({ status: "started" });
        break;

      case "PROXY_STOP":
        await sendMessageToTab(targetTabId, { cmd: "STOP" });
        sendResponse({ status: "sent_stop" });
        break;

      case "PROXY_PAUSE":
        await sendMessageToTab(targetTabId, { cmd: "PAUSE" });
        sendResponse({ status: "sent_pause" });
        break;

      case "PROXY_RESUME":
        await sendMessageToTab(targetTabId, { cmd: "RESUME" });
        sendResponse({ status: "sent_resume" });
        break;

      case "PROXY_SCAN_GROUPS": {
        // Điều hướng nhanh sang trang groups nếu cần để việc scan ổn định hơn
        try { await chrome.tabs.update(targetTabId, { url: "https://www.facebook.com/groups/you/" }); } catch {}
        await new Promise(r => setTimeout(r, 1500));
        const response = await sendMessageToTabWithResponse(targetTabId, { cmd: "SCAN_GROUPS_AND_RETURN" }, 3, 1500);
        sendResponse({ status: "success", groups: response?.groups || [] });
        break;
      }

      case "PROXY_FETCH_ALL_FRIENDS": {
        // 1) Điều hướng đúng URL friends/list để content.js cào ổn định
        try { await chrome.tabs.update(targetTabId, { url: "https://www.facebook.com/friends/list" }); } catch (e) {
          console.warn("Không update URL friends/list:", e);
        }
        // 2) Chờ trang tải
        await new Promise(r => setTimeout(r, 2500));
        // 3) Gửi lệnh có retry + chờ response
        try {
          const friendsResponse = await sendMessageToTabWithResponse(
            targetTabId,
            { cmd: "FETCH_ALL_FRIENDS" },
            3, // retries
            2000
          );
          return sendResponse({ status: "success", friends: friendsResponse?.friends || [] });
        } catch (e) {
          console.error("FETCH_ALL_FRIENDS fail:", e);
          return sendResponse({ status: "error", message: e.message || "Unknown error" });
        }
      }

      default:
        sendResponse({ status: "unknown_command" });
        break;
    }
  })();

  return true; // Luôn return true để giữ kết nối mở
});

