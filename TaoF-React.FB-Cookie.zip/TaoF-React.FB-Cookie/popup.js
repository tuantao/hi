// ===== Helpers =====
const $ = (id) => document.getElementById(id);

// ===== UI Elements =====
const btnImport = $("btnImport");
const cookieDataInput = $("cookieData");
const statusElement = $("status");
const fileSelectLink = $("fileSelectLink");
const fileInput = $("fileInput");

// ===== File Import Logic =====
fileSelectLink.addEventListener("click", () => {
    fileInput.click();
});

fileInput.addEventListener("change", (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        cookieDataInput.value = e.target.result;
        statusElement.innerHTML = `<span class="ok">Đã tải nội dung từ tệp: <strong>${file.name}</strong></span>`;
    };
    reader.onerror = () => {
        statusElement.innerHTML = `<span class="err">❌ Lỗi khi đọc tệp.</span>`;
    };
    reader.readAsText(file);
    fileInput.value = '';
});

// ===== Cookie Parsing Logic (NÂNG CẤP) =====

// 1. Hàm xử lý định dạng JSON (mặc định)
function parseJsonCookies(jsonString) {
    const data = JSON.parse(jsonString);
    const cookies = data.cookies || (Array.isArray(data) ? data : []);
    if (!Array.isArray(cookies) || cookies.length === 0) {
      throw new Error('Cấu trúc JSON không hợp lệ.');
    }
    return cookies;
}

// 2. Hàm xử lý định dạng Netscape
function parseNetscapeCookies(netscapeString) {
    const cookies = [];
    const lines = netscapeString.split('\n');
    const now = Date.now() / 1000;

    for (const line of lines) {
        if (line.startsWith('#') || line.trim() === '') continue;

        const parts = line.split('\t');
        if (parts.length < 7) continue;

        const [domain, , path, secure, expiration, name, value] = parts;
        
        // Bỏ qua cookie đã hết hạn
        if (parseInt(expiration, 10) < now && expiration !== '0') continue;

        cookies.push({
            domain: domain,
            path: path,
            secure: secure === 'TRUE',
            expirationDate: expiration === '0' ? undefined : parseInt(expiration, 10),
            name: name,
            value: value,
            httpOnly: false, // Netscape format does not specify this
            sameSite: 'no_restriction'
        });
    }
    return cookies;
}

// 3. Hàm xử lý định dạng Header String
function parseHeaderStringCookies(headerString) {
    const cookies = [];
    const pairs = headerString.split('; ');
    const domain = prompt("Vui lòng nhập domain cho cookie (ví dụ: .facebook.com):", ".facebook.com");
    if (!domain) throw new Error("Cần phải có domain.");

    for (const pair of pairs) {
        const [name, ...valueParts] = pair.split('=');
        if (name && valueParts.length > 0) {
            cookies.push({
                name: name.trim(),
                value: valueParts.join('=').trim(),
                domain: domain,
                path: '/',
                secure: true,
                httpOnly: true,
                sameSite: 'no_restriction'
            });
        }
    }
    return cookies;
}


// ===== Main Import Logic =====
btnImport.addEventListener("click", async () => {
    const rawData = cookieDataInput.value.trim();
    if (!rawData) {
        statusElement.innerHTML = `<span class="err">❌ Vui lòng dán dữ liệu hoặc chọn tệp.</span>`;
        return;
    }

    statusElement.innerHTML = `<span class="muted">Đang xử lý...</span>`;
    let cookiesToImport = [];

    try {
        // Tự động nhận diện định dạng
        if (rawData.startsWith('[') || rawData.startsWith('{')) {
            // Định dạng JSON
            statusElement.innerHTML += '<br/><small>Đã nhận diện định dạng: JSON</small>';
            cookiesToImport = parseJsonCookies(rawData);
        } else if (rawData.includes('\t')) {
            // Định dạng Netscape (dùng tab để phân tách)
            statusElement.innerHTML += '<br/><small>Đã nhận diện định dạng: Netscape</small>';
            cookiesToImport = parseNetscapeCookies(rawData);
        } else if (rawData.includes('=')) {
            // Định dạng Header String (dùng dấu ;)
            statusElement.innerHTML += '<br/><small>Đã nhận diện định dạng: Header String</small>';
            cookiesToImport = parseHeaderStringCookies(rawData);
        } else {
            throw new Error('Định dạng cookie không được hỗ trợ hoặc không hợp lệ.');
        }

        if (cookiesToImport.length === 0) {
            throw new Error("Không tìm thấy cookie hợp lệ nào trong dữ liệu.");
        }

        let successCount = 0;
        let errorCount = 0;

        for (const cookie of cookiesToImport) {
            const { hostOnly, session, ...restOfCookie } = cookie;
            const url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain.replace(/^\./, '') + (cookie.path || '/');
            const cookieDetails = { ...restOfCookie, url: url };
            delete cookieDetails.storeId;
            
            // Chrome yêu cầu expirationDate phải là số (seconds since epoch)
            if (cookieDetails.expirationDate && typeof cookieDetails.expirationDate !== 'number') {
                cookieDetails.expirationDate = parseInt(cookieDetails.expirationDate, 10);
            }

            try {
                await chrome.cookies.set(cookieDetails);
                successCount++;
            } catch (e) {
                errorCount++;
                console.error("Lỗi khi import cookie:", cookie.name, e.message);
            }
        }

        if (errorCount > 0) {
            statusElement.innerHTML = `<span class="ok">✅ Hoàn tất:</span> Đã import ${successCount} cookies, <span class="err">thất bại ${errorCount}.</span>`;
        } else {
            statusElement.innerHTML = `<span class="ok">✅ Đã import thành công ${successCount} cookies.</span>`;
        }

    } catch (e) {
        statusElement.innerHTML = `<span class="err">❌ Lỗi: ${e.message}</span>`;
    }
});