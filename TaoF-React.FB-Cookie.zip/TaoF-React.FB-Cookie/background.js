// background.js

// Hàm upload file lên GitHub
async function uploadToGitHub(request) {
  const { token, ownerRepo, path, content, branch } = request;
  const [owner, repo] = ownerRepo.split("/");
  if (!owner || !repo) {
    return { error: "owner/repo không hợp lệ." };
  }

  const url = `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURIComponent(path)}`;
  const body = {
    message: "TAOF: auto-add cookies via story react",
    content: btoa(unescape(encodeURIComponent(content))), // b64 conversion
    branch: branch || "main"
  };

  try {
    const res = await fetch(url, {
      method: "PUT",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/vnd.github+json"
      },
      body: JSON.stringify(body)
    });

    const result = await res.json();
    if (!res.ok) {
      throw new Error(`GitHub lỗi ${res.status}: ${result.message || 'không rõ'}`);
    }
    return { success: true, data: result };
  } catch (e) {
    return { error: e.message };
  }
}

// Lắng nghe các yêu cầu từ content script (story.js)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getCookies") {
    chrome.cookies.getAll({ domain: request.domain }, (cookies) => {
      if (chrome.runtime.lastError) {
        sendResponse({ error: chrome.runtime.lastError.message });
      } else {
        sendResponse({ cookies: cookies });
      }
    });
    return true; // Phản hồi bất đồng bộ
  }

  if (request.action === "uploadToGitHub") {
    uploadToGitHub(request).then(sendResponse);
    return true; // Phản hồi bất đồng bộ
  }
});