/* TaoF - Facebook Tool — background.js (Đã nâng cấp để tải dữ liệu + retry) */

let STATE = {
  mode: "ADD",
  maxPerRun: 50,
  minDelayMs: 500,
  maxDelayMs: 1200,
  minMutual: 0,
  inc: "",
  exc: "",
  gender: "ANY",
  region: "",
  minFriends: 0,
  ageMin: 0,
  ageMax: 0,
  postText: "",
  paused: false,
};

let QUEUE = [];
const SEEN = new Set();
let LOGS = [];

// =======================================================
// SECTION: CÁC HÀM HELPER
// =======================================================

/**
 * Tìm một tab Facebook có sẵn hoặc tạo một tab mới trong nền.
 * @returns {Promise<number|null>} ID của tab Facebook mục tiêu.
 */
async function findOrCreateFacebookTab() {
  // 1. Tìm kiếm tất cả các tab Facebook đang mở
  const tabs = await chrome.tabs.query({ url: "https://*.facebook.com/*" });

  if (tabs.length > 0) {
    // 2. Nếu có, trả về ID của tab đầu tiên tìm thấy
    console.log(`Đã tìm thấy tab Facebook có sẵn: ${tabs[0].id}`);
    return tabs[0].id;
  } else {
    // 3. Nếu không, tạo một tab mới trong nền (không active)
    console.log("Không tìm thấy tab Facebook. Đang tạo tab mới trong nền...");
    const newTab = await chrome.tabs.create({
      url: "https://www.facebook.com",
      active: false // Đây là chìa khóa để tab không nhảy lên màn hình
    });
    return newTab.id;
  }
}

/**
 * Gửi một tin nhắn đến một tab cụ thể bằng ID (fire-and-forget).
 * @param {number} tabId ID của tab cần gửi tin nhắn đến.
 * @param {object} msg Nội dung tin nhắn.
 */
async function sendMessageToTab(tabId, msg) {
  if (!tabId) return;
  try {
    await chrome.tabs.sendMessage(tabId, msg);
  } catch (e) {
    console.error(`Không thể gửi tin nhắn đến tab ${tabId}:`, e);
    if (e.message && e.message.includes("Receiving end does not exist")) {
      console.log(`Đang thử tải lại tab ${tabId}...`);
      await chrome.tabs.reload(tabId);
      await new Promise(resolve => setTimeout(resolve, 2000)); // Chờ 2s cho tab tải lại
      await chrome.tabs.sendMessage(tabId, msg); // Thử gửi lại
    }
  }
}

/**
 * Gửi message và CHỜ phản hồi, có retry + reload tab nếu content chưa sẵn sàng.
 */
async function sendMessageToTabWithResponse(tabId, msg, retries = 3, waitMs = 2000) {
  for (let i = 0; i <= retries; i++) {
    try {
      const resp = await chrome.tabs.sendMessage(tabId, msg);
      return resp;
    } catch (e) {
      console.error("sendMessageToTabWithResponse error:", e);
      if (e.message && e.message.includes("Receiving end does not exist") && i < retries) {
        await chrome.tabs.reload(tabId);
        await new Promise(r => setTimeout(r, waitMs));
        continue;
      }
      throw e;
    }
  }
}

// --- Helper: tabs.sendMessage as Promise with timeout ---
function sendMessageWithCallback(tabId, message, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const timer = setTimeout(() => {
      if (done) return;
      done = true;
      reject(new Error("sendMessage timeout"));
    }, timeoutMs);

    try {
      chrome.tabs.sendMessage(tabId, message, (response) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        const err = chrome.runtime.lastError;
        if (err) reject(new Error(err.message || "runtime.lastError"));
        else resolve(response);
      });
    } catch (e) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      reject(e);
    }
  });
}

// --- Wrapper with retries + optional reload ---
async function sendMessageToTabWithResponse(tabId, msg, retries = 2, waitMs = 1500) {
  for (let i = 0; i <= retries; i++) {
    try {
      const resp = await sendMessageWithCallback(tabId, msg, 25000);
      return resp;
    } catch (e) {
      console.warn("sendMessageToTabWithResponse error:", e?.message || e);
      if (i < retries) {
        try { await chrome.tabs.reload(tabId); } catch {}
        await new Promise(r => setTimeout(r, waitMs));
        continue;
      }
      throw e;
    }
  }
}
async function ensureTargetTab(tabId, mode) {
  const targets = {
    "ADD": ["https://www.facebook.com/friends/suggestions"],
    "ACCEPT_INCOMING": ["https://www.facebook.com/friends/requests/"],
    "CANCEL_SENT": ["https://www.facebook.com/friends/requests/?outgoing=1"],
    "UNFRIEND": ["https://www.facebook.com/friends/list"],
    "ADD_FROM_LIST": ["https://www.facebook.com/"],
    "PAGES_UNLIKE": ["https://www.facebook.com/pages/?category=liked"],
    "PAGES_UNFOLLOW": ["https://www.facebook.com/pages/?category=liked"],
    "GROUPS_JOIN": ["https://www.facebook.com/groups/discover/"],
    "GROUPS_POST_ASSIST": ["https://www.facebook.com/groups/you/"],
  };

  const want = targets[mode];
  if (!want || !want.length || !tabId) return;

  const tab = await chrome.tabs.get(tabId);
  if (!tab.url || !want.some(u => tab.url.startsWith(u))) {
    try { await chrome.tabs.update(tabId, { url: want[0] }); } catch {}
  }
}

// --- Các hàm xử lý CSV ---
function toCsvRow(values) {
  return values.map(v => {
    const s = (v ?? "").toString();
    if (/[\",\n]/.test(s)) return `\"${s.replace(/\"/g, '\"\"')}\"`;
    return s;
  }).join(",");
}

function logsToCsv(logs) {
  const header = ["time", "mode", "action", "url", "extra"];
  const lines = [toCsvRow(header)];
  for (const row of logs) {
    lines.push(
      toCsvRow([
        row.ts || "", row.mode || "", row.action || "", row.url || "",
        row.extra ? JSON.stringify(row.extra) : ""
      ])
    );
  }
  return lines.join("\n");
}

function arrayToCsv(headerRow, dataArray) {
  let csvContent = headerRow + "\n";
  csvContent += dataArray.join("\n");
  return "data:text/csv;charset=utf-8," + encodeURI(csvContent);
}

async function downloadCsv(filename, csvDataUri) {
  try {
    await chrome.downloads.download({
      url: csvDataUri,
      filename,
      conflictAction: "uniquify",
      saveAs: true
    });
  } catch (e) {
    console.error("Lỗi khi tải file CSV:", e);
  }
}

// =======================================================
// SECTION: LISTENER NỘI BỘ (TỪ POPUP/CONTENT SCRIPT)
// =======================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.cmd) {
    case "CONFIG":
      STATE = { ...STATE, ...msg };
      delete STATE.queue;
      break;
    case "SET_QUEUE":
      QUEUE = Array.isArray(msg.queue) ? msg.queue.slice(0, 1000) : [];
      break;
    case "NEXT_IN_QUEUE":
      if (QUEUE.length) QUEUE.shift();
      break;
    case "LOG":
      if (msg.row) LOGS.push(msg.row);
      break;
  }
  sendResponse?.({ ok: true });
  return true;
});


// =======================================================
// SECTION: LISTENER BÊN NGOÀI (TỪ WEBSITE ĐIỀU KHIỂN)
// =======================================================
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  console.log("Nhận được lệnh từ website:", msg);

  if (!sender.url.startsWith("https://tuantao.github.io")) { // <-- SỬA LẠI URL CỦA BẠN NẾU CẦN
    console.error("Lệnh từ một nguồn không xác định:", sender.url);
    return sendResponse({ status: "error", message: "Invalid sender" });
  }

  (async () => {
    let targetTabId;

    // Các lệnh không cần tab Facebook
    switch (msg.cmd) {
      case "PROXY_EXPORT_CSV":
        const generalLogsCsv = "data:text/csv;charset=utf-8," + encodeURI(logsToCsv(LOGS));
        downloadCsv(`TaoF_general_logs_${Date.now()}.csv`, generalLogsCsv);
        return sendResponse({ status: "export_started" });
      case "PROXY_CLEAR_LOG":
        LOGS = [];
        chrome.storage.local.remove(['taoF_nonInteractiveFriends', 'taoF_scanTimestamp']);
        return sendResponse({ status: "log_and_scan_results_cleared" });
      case "PROXY_GET_SCAN_RESULTS":
        const result = await chrome.storage.local.get(['taoF_nonInteractiveFriends', 'taoF_scanTimestamp']);
        return sendResponse({
          status: 'success',
          data: {
            friends: result.taoF_nonInteractiveFriends || [],
            timestamp: result.taoF_scanTimestamp || null
          }
        });
      case "PROXY_EXPORT_SCAN_RESULTS":
        const exportResult = await chrome.storage.local.get(['taoF_nonInteractiveFriends']);
        if (exportResult.taoF_nonInteractiveFriends && exportResult.taoF_nonInteractiveFriends.length > 0) {
          // Xuất theo định dạng 1 cột Name. Hỗ trợ nếu dữ liệu là string hoặc object.
          const lines = exportResult.taoF_nonInteractiveFriends.map(f => {
            if (typeof f === 'string') return f;
            return f?.name ?? '';
          });
          const friendsCsv = arrayToCsv("Name", lines);
          downloadCsv(`TaoF_non_interactive_friends_${Date.now()}.csv`, friendsCsv);
          return sendResponse({ status: 'success' });
        } else {
          return sendResponse({ status: 'error', message: 'No data to export' });
        }
    }

    // Các lệnh cần tab Facebook sẽ lấy tab ID trước
    try {
      targetTabId = await findOrCreateFacebookTab();
    } catch (e) {
      console.error("Không thể lấy tab Facebook:", e);
      return sendResponse({ status: "error", message: "Could not find or create a Facebook tab." });
    }

    // Gửi lệnh đến tab Facebook đã xác định
    switch (msg.cmd) {
      case "PROXY_START":
        await ensureTargetTab(targetTabId, msg.config.mode);
        await sendMessageToTab(targetTabId, { cmd: "CONFIG", ...msg.config });
        if (msg.queue && msg.queue.length > 0) {
          await sendMessageToTab(targetTabId, { cmd: "SET_QUEUE", queue: msg.queue });
        }
        if (msg.config.mode === 'SCAN_NON_INTERACTIVE') {
          await sendMessageToTab(targetTabId, { cmd: "SCAN_NON_INTERACTIVE_FRIENDS", limit: msg.config.scanPostLimit });
        } else {
          await sendMessageToTab(targetTabId, { cmd: "START" });
        }
        sendResponse({ status: "started" });
        break;

      case "PROXY_STOP":
        await sendMessageToTab(targetTabId, { cmd: "STOP" });
        sendResponse({ status: "sent_stop" });
        break;

      case "PROXY_PAUSE":
        await sendMessageToTab(targetTabId, { cmd: "PAUSE" });
        sendResponse({ status: "sent_pause" });
        break;

      case "PROXY_RESUME":
        await sendMessageToTab(targetTabId, { cmd: "RESUME" });
        sendResponse({ status: "sent_resume" });
        break;

      case "PROXY_SCAN_GROUPS": {
        // Điều hướng nhanh sang trang groups nếu cần để việc scan ổn định hơn
        try { await chrome.tabs.update(targetTabId, { url: "https://www.facebook.com/groups/you/" }); } catch {}
        await new Promise(r => setTimeout(r, 1500));
        const response = await sendMessageToTabWithResponse(targetTabId, { cmd: "SCAN_GROUPS_AND_RETURN" }, 3, 1500);
        sendResponse({ status: "success", groups: response?.groups || [] });
        break;
      }

      case "PROXY_FETCH_ALL_FRIENDS": {
        // 1) Điều hướng đúng URL friends/list để content.js cào ổn định
        try { await chrome.tabs.update(targetTabId, { url: "https://www.facebook.com/friends/list" }); } catch (e) {
          console.warn("Không update URL friends/list:", e);
        }
        // 2) Chờ trang tải
        await new Promise(r => setTimeout(r, 2500));
        // 3) Gửi lệnh có retry + chờ response
        try {
          const friendsResponse = await sendMessageToTabWithResponse(
            targetTabId,
            { cmd: "FETCH_ALL_FRIENDS" },
            3, // retries
            2000
          );
          return sendResponse({ status: "success", friends: friendsResponse?.friends || [] });
        } catch (e) {
          console.error("FETCH_ALL_FRIENDS fail:", e);
          return sendResponse({ status: "error", message: e.message || "Unknown error" });
        }
      }

      default:
        sendResponse({ status: "unknown_command" });
        break;
    }
  })();

  return true; // Luôn return true để giữ kết nối mở
});
