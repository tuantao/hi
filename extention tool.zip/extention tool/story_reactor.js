(function() {
    'use strict';

    if (window.StoryReactorInstance) {
        window.StoryReactorInstance.destroy();
    }

    class StoryReactor {
        constructor() {
            this.emojiList = [];
            this.container = null;
            this.isInitialized = false;
            this.observer = null;
            this.cacheKey = 'emoji_cache_v2';
            this.cacheTTL = 24 * 60 * 60 * 1000;
            this.isAttached = false;
            this.handleNavigation = this.handleNavigation.bind(this);
            this.checkAndAttach = this.checkAndAttach.bind(this);
        }

        async init() {
            if (this.isInitialized) return;
            try {
                await this.loadEmojiData();
                this.setupNavigationListener();
                this.startObserving();
                this.handleNavigation();
                this.isInitialized = true;
                console.log('StoryReactor initialized');
            } catch (err) {
                console.error('Failed to initialize StoryReactor:', err);
            }
        }
        
        async loadEmojiData() {
            const cachedData = this.getCachedData();
            if (cachedData) {
                this.emojiList = cachedData;
                return;
            }
            try {
                const response = await fetch('https://raw.githubusercontent.com/KimiZK-Dev/Tao-lao/refs/heads/main/emoji.json');
                if (!response.ok) throw new Error(`HTTP error ${response.status}`);
                this.emojiList = await response.json();
                this.setCachedData(this.emojiList);
            } catch (err) {
                 console.warn(`Emoji fetch failed:`, err);
                 // Fallback to a small default list
                 this.emojiList = [{"codes":"1F600","char":"😀","name":"grinning face"}, {"codes":"1F602","char":"😂","name":"face with tears of joy"}, {"codes":"2764","char":"❤️","name":"red heart"}, {"codes":"1F44D","char":"👍","name":"thumbs up"}];
            }
        }

        getCachedData() {
            try {
                const item = localStorage.getItem(this.cacheKey);
                if (item) {
                    const { data, timestamp } = JSON.parse(item);
                    if (Date.now() - timestamp < this.cacheTTL) return data;
                }
            } catch (e) {}
            return null;
        }

        setCachedData(data) {
            try {
                localStorage.setItem(this.cacheKey, JSON.stringify({ data, timestamp: Date.now() }));
            } catch (e) {}
        }
        
        isStoryUrl() {
            return window.location.href.includes('/stories/');
        }

        buildGroupCache() {
            const groupCache = new Map();
            this.emojiList.forEach(e => {
                const groupName = e.group || e.category;
                if (!groupCache.has(groupName)) groupCache.set(groupName, []);
                groupCache.get(groupName).push(e);
            });
            return groupCache;
        }

        async setupUI() {
            if (this.container) this.container.remove();

            this.container = document.createElement("div");
            this.container.className = "react-container";
            
            const button = document.createElement("button");
            button.className = "btn-react";
            button.innerHTML = `...`; // SVG content here

            const panel = document.createElement("div");
            panel.className = "emoji-panel";

            const searchInput = document.createElement("input");
            searchInput.placeholder = "Tìm kiếm...";
            searchInput.className = "emoji-search";
            
            const listContainer = document.createElement("div");
            listContainer.className = "emoji-list-container";
            const emojiListElement = document.createElement("ul");
            emojiListElement.className = "emoji-group";

            listContainer.appendChild(emojiListElement);
            panel.appendChild(searchInput);
            panel.appendChild(listContainer);
            this.container.appendChild(button);
            this.container.appendChild(panel);

            this.addEventListeners({ button, panel, searchInput, emojiListElement, listContainer });
            this.renderGroupTabs(panel, emojiListElement);
        }
        
        renderGroupTabs(panel, emojiListElement) {
            const groupCache = this.buildGroupCache();
            const tabContainer = document.createElement("div");
            tabContainer.className = "emoji-group-tabs";
            
            const allTab = document.createElement("div");
            allTab.className = "emoji-tab active";
            allTab.textContent = "All";
            allTab.title = "Tất cả";
            allTab.dataset.group = "all";
            tabContainer.appendChild(allTab);

            groupCache.forEach((group, name) => {
                const tab = document.createElement("div");
                tab.className = "emoji-tab";
                tab.textContent = group[0].char;
                tab.title = name;
                tab.dataset.group = name;
                tabContainer.appendChild(tab);
            });
            
            panel.appendChild(tabContainer);

            tabContainer.addEventListener('click', (e) => {
                const tab = e.target.closest('.emoji-tab');
                if (tab) {
                    const groupName = tab.dataset.group;
                    const emojis = groupName === 'all' ? this.emojiList : groupCache.get(groupName) || [];
                    this.renderEmojis(emojiListElement, emojis);
                    panel.querySelectorAll(".emoji-tab").forEach(t => t.classList.remove("active"));
                    tab.classList.add("active");
                }
            });
        }
        
        renderEmojis(listElement, emojis) {
            listElement.innerHTML = "";
            const frag = document.createDocumentFragment();
            emojis.forEach(e => {
                const li = document.createElement("li");
                li.className = "emoji";
                li.textContent = e.char;
                li.title = e.name;
                li.dataset.emoji = e.char;
                frag.appendChild(li);
            });
            listElement.appendChild(frag);
        }

        addEventListeners({ button, panel, searchInput, emojiListElement, listContainer }) {
            button.addEventListener("click", e => { e.stopPropagation(); panel.classList.toggle("show"); });
            document.addEventListener('click', e => { if (!this.container.contains(e.target)) panel.classList.remove("show"); });
            
            searchInput.addEventListener("input", e => {
                const term = e.target.value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
                const filtered = this.emojiList.filter(em => em.name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").includes(term));
                this.renderEmojis(emojiListElement, filtered);
            });

            emojiListElement.addEventListener('click', e => {
                const emojiEl = e.target.closest('.emoji');
                if (emojiEl) this.handleReaction(emojiEl.dataset.emoji);
            });
        }

        startObserving() {
            this.stopObserving();
            const targetNode = document.body;
            const config = { childList: true, subtree: true };
            this.observer = new MutationObserver(() => this.checkAndAttach());
            this.observer.observe(targetNode, config);
        }
        
        stopObserving() {
            if (this.observer) this.observer.disconnect();
        }

        async checkAndAttach() {
            if (!this.isStoryUrl()) return;
            
            const footerSelectors = [
                "div[data-id] > div[role='contentinfo']",
                ".x11lhmoz.x78zum5.x1q0g3np",
                "[role='contentinfo']",
                ".x1yztbdb.x1sxj7lo"
            ];

            let footer = footerSelectors.map(s => document.querySelector(s)).find(Boolean);
            
            if (footer && !this.isAttached) {
                await this.setupUI();
                footer.appendChild(this.container);
                this.isAttached = true;
                console.log('StoryReactor attached');
            } else if (!footer) {
                this.isAttached = false;
            }
        }

        setupNavigationListener() {
            window.addEventListener('popstate', this.handleNavigation);
            window.addEventListener('hashchange', this.handleNavigation);
            const originalPushState = history.pushState;
            history.pushState = (...args) => {
                originalPushState.apply(history, args);
                this.handleNavigation();
            };
        }

        handleNavigation() {
            setTimeout(() => {
                if (this.isStoryUrl()) {
                    this.checkAndAttach();
                } else if (this.container && this.container.parentNode) {
                    this.container.remove();
                    this.isAttached = false;
                }
            }, 500);
        }

        async handleReaction(emoji) {
            try {
                const fbDtsg = document.querySelector('input[name="fb_dtsg"]')?.value || (document.documentElement.innerHTML.match(/"DTSGInitialData",\[],{"token":"(.+?)"/))?.[1];
                const userId = document.cookie.match(/c_user=(\d+)/)?.[1];
                const storyEl = document.querySelector(".xh8yej3.x1n2onr6[data-id]") || document.querySelector("[data-id]");
                let storyId = storyEl?.dataset.id || "";
                
                if (!userId || !fbDtsg || !storyId) throw new Error('Missing required parameters');

                const variables = { input: { lightweight_reaction_actions: { offsets: [0], reaction: emoji }, message: emoji, story_id: storyId, story_reply_type: "LIGHT_WEIGHT", actor_id: userId, client_mutation_id: Math.floor(Math.random() * 10) } };
                const body = new URLSearchParams({ fb_dtsg: fbDtsg, doc_id: "7134372739987323", variables: JSON.stringify(variables) });
                
                await fetch("/api/graphql/", { method: "POST", body });
                console.log('Reacted with:', emoji);

            } catch (err) {
                console.error('Failed to react:', err);
            }
        }

        destroy() {
            this.stopObserving();
            if (this.container) this.container.remove();
            window.removeEventListener('popstate', this.handleNavigation);
            window.removeEventListener('hashchange', this.handleNavigation);
            this.isInitialized = false;
        }
    }

    window.StoryReactorInstance = new StoryReactor();
    window.StoryReactorInstance.init();
})();