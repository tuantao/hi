document.getElementById('openDashboard').addEventListener('click', () => {
  const extId = "epmonfbcjiklobbhjkjkgkjaclnknmmk";
  const url = `https://tuantao.github.io/taof-ex/?extId=${extId}`;
  chrome.tabs.create({ url });
});